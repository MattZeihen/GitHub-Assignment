let a = 40, b = 0, c = -30, d = -90;

function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(180);
  //background clouds
  noStroke();
  fill(255);
  angleMode(DEGREES);
  if(a == 800){
  	a = 0;
  }
  ellipse(400,a,5,25);
  a = a+5;

  if(b == 800){
  	b = 0;
  }
  ellipse(200,b,5,25);
  b = b+5;

  if(c == 800){
  	c = 0;
  }
  ellipse(650,c,5,25);
  c = c+5;

  if(d == 800){
  	d = 0;
  }
  ellipse(780,d,5,25);
  d = d+5;



  
  fill(80);
  rect(0,0,800,20);
  ellipse(350,20,300,40);
  ellipse(650,30,180,60);
  ellipse(50,20,200,80);
  rotate(-5);
  ellipse(200,60,350,90);
  rotate(5);
  ellipse(530,10,120,120);
  ellipse(800,20,160,30);
  push();

  //background floor
  fill(85);
  rect(0,760,800,40);
  push();

  for(let i = 0; i < 2; i++){
  	tree((180+(300 * i)),-400,i);
  }
  push();

  volOfSun();
  let g = valRet();
  print(g);

}

function tree(x, height, scal){
	fill(100);
	s = scal+1;
	translate(x,760);
	scale(s);
	rect(0,0,40,height);
	fill(110);
	ellipse(-20,(height-40),120,90);
	ellipse(40,(height+20),103,134);
	ellipse(80,(height+5),100,110);
	translate(-x,-760);
}
function volOfSun(){
	print("The total volume of the sun is 1.4 x 1027cubic meters. About 1.3 million Earths could fit inside the sun.");
}
function valRet(){
	return(a);
}
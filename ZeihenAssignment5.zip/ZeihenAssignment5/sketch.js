let a1 =0,a2 = 0, a3 = 0,b = 0, b1 = 80,b2 = 80, b3 =80, c1 =0,c2 = 0,c3 = 0;
let x = 0, y = 0;

function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(217, 184, 165);
  noStroke();
  fill(194, 164, 147);
  rect(0,600,800,200);//the floor
  
  fill(89, 101, 158);
  rect(50,450,20,150);//left leg of left table
  rect(40,430,213,20);//left table top
  rect(223,450,20,150);//left table right leg

  
  rect(310,450,20,150);//left leg of middle table
  rect(300,430,213,20);//middle table top
  rect(483,450,20,150);//middle table right leg
  
  
  rect(570,450,20,150);//left leg of right table
  rect(560,430,213,20);//right table top
  rect(743,450,20,150);//right table right leg
  
  
  //left computer
  fill(135, 184, 199);
  rect(55,330,30,100,3);//computer tower
  rect(165.25,410,10,20);//computer stand connector
  rect(105,425,125,5,3);//computer stand/keyboard
  rect(100,320,135,90);//computer monitor
  

  //middle computer
  rect(315,330,30,100,3);//computer tower
  rect(425.25,410,10,20);//computer stand connector
  rect(365,425,125,5,3);//computer stand/keyboard
  rect(360,320,135,90);//computer monitor

  
  //right computer
  rect(575,330,30,100,3);//computer tower
  rect(685.25,410,10,20);//computer stand connector
  rect(625,425,125,5,3);//computer stand/keyboard
  rect(620,320,135,90);//computer monitor

  
  //left table chair
  //adding 260 pixels to x to move them over effectivley
  fill(202, 108, 217);
  rect(90, 420, 112.5, 110);//back of left chair
  rect(132.5,530,27.5,50);//supporting midle piece left chair
  rect(100,580,92.5,10);//wheel array holder left chair
  rect(100,590,20,10);//left wheel, left chair
  rect(136.25,590,20,10);//middle wheel, left chair.
  rect(172.5,590,20,10);//right wheel, left chair
  
  
  //middle table chair
  rect(350, 420, 112.5, 110);//back of chair
  rect(392.5,530,27.5,50);//supporting midle piece of chair
  rect(360,580,92.5,10);//wheel array holder of chair
  rect(360,590,20,10);//left wheel of chair
  rect(396.25,590,20,10);//middle wheel of chair.
  rect(432.5,590,20,10);//right wheel of chair
  
  
  //right table chair
  rect(610, 420, 112.5, 110);//back of chair
  rect(652.5,530,27.5,50);//supporting midle piece of chair
  rect(620,580,92.5,10);//wheel array holder of chair
  rect(620,590,20,10);//left wheel, of chair
  rect(656.25,590,20,10);//middle wheel of chair.
  rect(692.5,590,20,10);//right wheel of chair
  
  //left computer screen
  fill(a1,a2,a3);
  rect(105,325,125,80,10);
  
  //middle computer screen
  fill(b);
  rect(365,325,125,80,10);
  fill(b1,b2,b3);
  ellipse(430,365,40);
  
  //right computer
  
  if(keyIsPressed === true){
    c1= 92;
    c2=56;
    c3=176;
  }else{
    c1 = 0;
    c2 = 0;
    c3 = 0;  
  }
  fill(c1,c2,c3);
  rect(625,325,125,80,10);
  
}

function mousePressed(){
  x = mouseX;
  y = mouseY;
  //105,325,125,80
  if(x >= 105 && x<=230){
    if(y >= 325&& y <=405){
      if(a1 == 0){
        a1=227;
        a2=48;
        a3=107;
      }else{
        a1 = 0;
        a2 = 0;
        a3 = 0;
      }
    }
  }
}


function mouseClicked() {
  x = mouseX;
  y = mouseY;
  d =dist(x,y,430,365);
  //105,325,125,80
  if(d <= 20){
    b1=75; 
    b2=212;
    b3=68;
  }else{
    b1 = 80;
    b2=80;
    b3 = 80;
  }
}
let xy = [730,760,790];
let arr = [];
let mxy = [];
let inc = 0;
let inc1 = 0;
function setup() {
  createCanvas(800, 800);
}

function draw() {
	background(80);
	pac(400,400);
	dot(xy[inc1],400);
	if(inc1 == 0){
		inc1 = 1;
	}else if(inc1 == 1){
		inc1 = 2;
	}else{
		inc1 = 0;
	}
	for(let i = 0; i<10; i++){
		arr[i] = i;
		print(i + " = i");
		console.log(arr[i] + " = arr[i]");
	}

	mxy[inc] = mouseX;
	inc++;
	mxy[inc] = mouseY;
	inc++;
}

function pac(x,y){
	angleMode(DEGREES);
	translate(x,y);
	noStroke();
	fill(220, 255, 23);
	arc(0,0,190,190,25,335);
	translate(-x,-y);
}
function dot(x,y){
	noStroke();
	fill(245, 164, 2);
	translate(x,y);
	ellipse(0,0,20,20);
	translate(-x,-y);
}
